<?php
namespace Home\Controller;
use Think\Controller;


class AskController extends Controller {
		function showAllAsks($sort,$page=1,$pagesize=5){
			$ans=D('Ask','Service');
			$list=$ans->showAllAsk($sort,$page,$pagesize);
			
			$this->ajaxReturn($list);
		}
		
		function showOneAskInfo($aid){
			$ask=D('Ask','Service');
			$ans=D('Answer','Service');
			$rs=$ask->showOneAsk($aid);
			$rs1=$ans->showOneAskAswer($aid);
			$rs['answers']=$rs1;
			$rs['ansnum']=count($rs1);
			$this->ajaxReturn($rs);
		}
}