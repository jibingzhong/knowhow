<?php
namespace Home\Controller;
use Think\Controller;


class TagController extends Controller {
		function showAllTags($sort,$page=1,$pagesize=5){
			$ans=D('Tag','Service');
			$list=$ans->showAllTag($sort,$page,$pagesize);
// 			print_r($list);
 			$this->ajaxReturn($list);
		}
		function text(){
			$ans=D('Tag','Service');
			$list=$ans->showAllTag();
			print_r($list);
// 			$this->ajaxReturn($list);
		}

}