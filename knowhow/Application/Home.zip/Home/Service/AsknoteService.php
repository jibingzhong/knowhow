<?php
namespace Home\Service;
use Think\Model;

class AsknoteService extends Model{
		/**
		  * 作者
		  * 函数的描述
		  * 参数列表
		  * 返回值
		  * 函数被访问的接口列表
		  * 
		  * */
		
	public function insertAsknote(){
		
	}
	
	/**
	 * 作者
	 * 函数的描述
	 * 参数列表
	 * 返回值
	 * 函数被访问的接口列表     
	 *
	 * */
	public function queryAsknote(){
		
	}
	
	
}

?>